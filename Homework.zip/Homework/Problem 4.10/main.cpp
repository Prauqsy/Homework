#include <iostream>

using namespace std;

const int year=12;

int main(int argc, char** argv) {
    
    //Declare Variables
    int Mth, Yr, Dys, Lpyr;
    
    cout << "Enter a month (1-12): ";
        cin >>Mth;
    cout << "Enter a year: ";
        cin >> Yr;
        
        //if to determine days to output
        if (Mth==1||Mth==3||Mth==5||Mth==8||Mth==10||Mth==12)
            {
            Dys = 31;
            }  
                else if (Mth==4||Mth==6||Mth==9||Mth==11)
                        {
                         Dys = 30;
                        }
                else if (Mth==2)
                        {
                         Lpyr = (Yr % 4 == 0 && Yr % 100 != 0 || Yr % 400 == 0);
                         
                            //if it is not a leapyear output 29
                            if (!Lpyr)
                            Dys = 28;
                            else 
                            Dys = 29;
                        }
    //output after determining what not to output 
    cout << Dys <<" Days"<< endl;
    
    

    return 0;
}

