#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Declare Variable
    int Num;
    
    cout <<"Enter a number (no negative numbers): ";
        cin>>Num;
            //While to repeat until correct input is given
            while(Num<0)
                {
                 cout <<"No negative numbers. Enter number again: ";
                    cin>>Num;
                }
    //For to output numbers until inputted number is reached
    for ( int X=1; X<=Num; X++)
        {
        cout << X << endl;
        }
    

    return 0;
}

