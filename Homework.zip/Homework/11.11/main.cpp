/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Juan Tellez
 *
 * Created on October 8, 2017, 11:24 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

struct MBudget
{
    float hous, util, housE, trans, food, med, ins, ent, clth, misc;
};

void GBud(MBudget&);
void DBud(MBudget);
int main(int argc, char** argv) { 
    MBudget start;
    GBud(start);
    DBud(start);
    return 0;
}
void GBud(MBudget &a)
{
    cout<<"Enter housing cost: ";
        cin>>a.hous;
    cout<<"Enter utilities cost: ";
        cin>>a.util;
    cout<<"Enter house cost: ";
        cin>>a.housE;
    cout<<"Enter transportation cost: ";
        cin>>a.trans;
    cout<<"Enter food cost: ";
        cin>>a.food;
    cout<<"Enter medical cost: ";
        cin>>a.med;
    cout<<"Enter insurance cost: ";
        cin>>a.ins;
    cout<<"Enter entertainment cost: ";
        cin>>a.ent;
    cout<<"Enter clothing cost: ";
        cin>>a.clth;
    cout<<"Enter miscellaneous cost: ";
        cin>>a.misc;
}
void DBud(MBudget a)
{
    float Mtotal, Etotal, total;
    total=a.hous-500;
    cout<<"==============================================================="<<endl;
    cout<<"==============================================================="<<endl;
    if(total>0)
    {
        cout<<"Housing is over budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    else if(total<0)
    {
        cout<<"Housing is under budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    total=a.util-150;
    if(total>0)
    {
        cout<<"Utilities is over budget by:"<<setprecision(2)<<fixed<<total<<endl;
    }
    else if(total<0)
    {
        cout<<"Utilities is under budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    total=a.housE-65;
    if(total>0)
    {
        cout<<"Household expenses is over budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    else if(total<0)
    {
        cout<<"Household expenses is under budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    total=a.trans-50;
    if(total>0)
    {
        cout<<"Transportation is over budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    else if(total<0)
    {
        cout<<"Transportation is under budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    total=a.food-250;
    if(total>0)
    {
        cout<<"Food is over budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    else if(total<0)
    {
        cout<<"Food is under budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    total=a.med-30;
    if(total>0)
    {
        cout<<"Medical is over budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    else if(total<0)
    {
        cout<<"Medical is under budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    total=a.ins-100;
    if(total>0)
    {
        cout<<"Insurance is over budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    else if(total<0)
    {
        cout<<"Insurance is under budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    total=a.ent-150;
    if(total>0)
    {
        cout<<"Entertainment is over budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    else if(total<0)
    {
        cout<<"Entertainment is under budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    total=a.clth-75;
    if(total>0)
    {
        cout<<"Clothing is over budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    else if(total<0)
    {
        cout<<"Clothing is under budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    total=a.misc-50;
    if(total>0)
    {
        cout<<"Miscellaneous is over budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    else if(total<0)
    {
        cout<<"Miscellaneous is under budget by: "<<setprecision(2)<<fixed<<total<<endl;
    }
    
    Mtotal=a.clth+a.ent+a.food+a.hous+a.housE+a.ins+a.med+a.misc+a.trans+a.util;
    Etotal=Mtotal-1420;
    if(Etotal>0)
    {
        cout<<"Monthly expenses are over budget by: "<<setprecision(2)<<fixed<<Etotal<<endl;
    }
    else
    {
        cout<<"Monthly expenses are under budget by: "<<setprecision(2)<<fixed<<Etotal<<endl;
    }
    
    
    
}
