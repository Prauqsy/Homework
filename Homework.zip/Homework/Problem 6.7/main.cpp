#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

//function declared
float C(float F);


int main(int argc, char** argv) {
    
    
    cout<< "Fahrenheit     Celsius" << endl;
    //creating Fahrenheit 0-20°
    for (int F=0; F<=20; F++)
        { 
        //call to function
        float CT=C(F);
            cout << F;
            cout <<fixed << setprecision (2) << setw (20) << CT << endl;
        }
    
    //pointless return here but I like it and i'm keeping it
     return 0;
}

//new function for celsius
float C (float F){
    //equation for fehrenheit to celsius converstion
    float C=0.55555556*(F-32);
    
    // returning output to main function
    return C;
    }
