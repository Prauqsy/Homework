/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   main.cpp
 * Author: Juan Tellez
 *
 * Created on October 4, 2017, 2:38 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;

struct Speakers{
    string Name, Topic;
    float TelNum;
    float Fee;
};

int main(int argc, char** argv) {
    
    int num, let, elm;
    Speakers array[10];
    
    do
    {
        cout<<"Type 1 to fill array with data"<<endl;
        cout<<"Type 2 to change the contents of an element"<<endl;
        cout<<"Type 3 to display all the data in the array"<<endl;
        cout<<"Type 4 to exit"<<endl;
            cin>>num;
        switch(num)
        {
            case 1:
                for (int i=0;i<10;i++)
                {    
                cout<<"Enter name of speaker: ";
                    cin>>array[i].Name;
                cout<<"Enter telephone number: ";
                    cin>>array[i].TelNum;
                cout<<"Enter topic: ";
                    cin>>array[i].Topic;
                cout<<"Enter fee: ";
                    cin>>array[i].Fee;
                
                        while(array[i].Fee<0)
                        {
                            cout<<"Fee cannot be negative please reenter fee: ";
                                cin>>array[i].Fee;
                        }
                }   
                    break;
            case 2:

                cout<<"Enter number of element you would like to change: ";
                    cin>>let;
                cout<<"Enter name of speaker: ";
                    cin>>array[let].Name;
                cout<<"Enter telephone number: ";
                    cin>>array[let].TelNum;
                cout<<"Enter topic: ";
                    cin>>array[let].Topic;
                cout<<"Enter fee: ";
                    cin>>array[let].Fee;
                
                    while(array[let].Fee<0)
                    {
                        cout<<"Fee cannot be negative please reenter fee: ";
                                cin>>array[let].Fee;
                    }
                break;
            case 3: 
                for(int i=0;i<10;i++)
                {    
                cout<<"Speaker's name: "<<array[i].Name<<endl;
                cout<<"Telephone number: "<<setprecision(15)<<array[i].TelNum<<endl;
                cout<<"Topic: "<<array[i].Topic<<endl;
                cout<<"Fee: "<<setprecision(2)<<fixed<<array[i].Fee<<endl;
                }
                break;
           
                
        }
     
    }
    while(num!=4);
    
    return 0;
}
    