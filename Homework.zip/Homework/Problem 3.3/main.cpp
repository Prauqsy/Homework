#include <iostream>
#include <iomanip>

using namespace std;


int main(int argc, char** argv) {
    //Declare Variables
    float A, B, C, D, E, F, X;
    
    cout <<"Enter 1st test score: ";
        //All cin=User inputs
        cin>>A;
    cout<<"Enter 2nd test score: ";
        cin>>B;
    cout<<"Enter 3rd test score: ";
        cin>>C;
    cout<<"Enter 4th test score: ";
        cin>>D;
    cout<<"Enter 5th test score: ";
        cin>>F;
        
        //Average test scores equation
        X=(A+B+C+D+F)/5;
     // Average test score equation output with decimal point constraints    
    cout<<"Average test score: " << fixed << setprecision (1) << X << endl;
        
    return 0;
}

