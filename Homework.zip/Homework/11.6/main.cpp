/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Juan Tellez
 *
 * Created on October 6, 2017, 7:35 PM
 */

#include <iostream>

using namespace std;
    
struct Player
{
    string Name;
    int Num, Pts;
};

int main(int argc, char** argv) {  
    int total,top, tp;
    Player soccer[12];
            
    for(int i=0;i<12;i++)
    {
        cout<<"Enter player's name: ";
            cin>>soccer[i].Name;
        cout<<"Enter player's number: ";
            cin>>soccer[i].Num;
        while(soccer[i].Num<0)
        {
            cout<<"No negative numbers please re-enter the number: ";
                cin>>soccer[i].Num;
        }
        cout<<"Enter player's points: ";
            cin>>soccer[i].Pts;
        while(soccer[i].Pts<0)
        {
            cout<<"No negative numbers please re-enter the points: ";
                cin>>soccer[i].Pts;
        }
    }
    cout<<""<<endl;
    cout<<""<<endl;
    cout<<""<<endl;
    cout<<"Table of players, number, and points scored."<<endl;
    for(int x=0;x<12;x++)
    {
        cout<<"==================="<<endl;
        cout<<soccer[x].Name<<" | ";
        cout<<soccer[x].Num<<" | ";
        cout<<soccer[x].Pts<<endl;
        cout<<"==================="<<endl;
    total+=soccer[x].Pts;
    }
    top=soccer[0].Pts;
    for(int y=1;y<12;y++)
    {
        if(soccer[y].Pts>top)
        {
            top=soccer[y].Pts;
            tp=y;
        }
    }
    
    cout<<"===================="<<endl;
    cout<<"Top Player: "<<soccer[tp].Name<<endl;
    cout<<"Number: "<<soccer[tp].Num<<endl;
    cout<<"Points: "<<top<<endl;
    
    
    
    return 0;
}

