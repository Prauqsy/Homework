/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Prauqsy
 *
 * Created on October 20, 2017, 1:42 PM
 */

#include <iostream>

#include "Car.h"
using namespace std;
int main(int argc, char** argv) {
    Car car(2015, "Volkswager");
    cout<<"Car's make: "<<car.getMake()<<endl;
    cout<<"Car's year: "<<car.getYear()<<endl;
    cout<<"Car's speed: "<<car.getSpeed()<<endl;
    for(int i=0; i<5; i++)
    {
        car.aclel()
        cout<<"Speed after accelerate: "<<car.getSpeed()<<endl;
    }
    
    for(int i=0; i<5; i++)
    {
        car.brake();
        cout<<"Speed after brake: "<<car.getSpeed()<<endl;        
    }

    return 0;
}

