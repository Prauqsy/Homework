/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Car.h
 * Author: Prauqsy
 *
 * Created on October 20, 2017, 10:25 PM
 */

#ifndef CAR_H
#define CAR_H
#include <string>
class Car
{
    private:
        int yearModel;
        string make;
        int speed;
    public:
        Car(int, int, string)
        int yr();
        string m();
        int getSpeed();
        int getYear();
        string getMake();
        void aclel();
        void brake();
};
#endif /* CAR_H */

