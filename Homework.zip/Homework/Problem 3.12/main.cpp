#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Declare Variables
    float F, C;
   
    cout << "Enter the Temperature you would like to convert."<< endl;
        //User input
        cin >> C;

        //Celsius to Fahrenheit equation 
        F=1.8*C+32;
        
    //Equation output
    cout << C <<"°C =" << F <<"°F" << endl;
   
    return 0;
}

