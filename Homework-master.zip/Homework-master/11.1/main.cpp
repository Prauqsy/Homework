/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Juan Tellez
 *
 * Created on October 9, 2017, 1:16 PM
 */

#include <iostream>

using namespace std;

struct Mdata
{
    string Title, Director;
    int year;
    float Rtime;
};
void Sdata(Mdata);
int main(int argc, char** argv) {
    
    Mdata movie1, movie2;
    
    cout<<"Enter movie title: ";
        cin>>movie1.Title;
    cout<<"Enter name of director: ";
        cin>>movie

    return 0;
}

