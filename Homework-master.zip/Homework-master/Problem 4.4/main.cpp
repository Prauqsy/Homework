#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Declare variables
    float L1, L2, W1, W2, A1, A2;
    
    cout<<"Enter length and width of triangle 1: ";
            cin>>L1>>W1;
    cout<<"Enter length and width of triangle 2: ";
            cin>>L2>>W2;
            
            //Area of a triable equations
            A1=L1*W1;
            A2=L2*W2;
            
            //If to determine which triangle is bigger and output at the same time
            if (A1<A2)
                {
                cout<<"Triangle 2 has the greater area";
                }
                    else if(A1>A2)
                        {
                        cout<<"Triangle 1 has the greater area";
                        }
                    else if(A1==A2)
                        {
                        cout<<"Triangles have the same area";
                        }
    return 0;
}

