/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Juan Tellez
 *
 * Created on October 8, 2017, 10:53 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

struct CusData
{
    string Name, Address, City, State;
    int Zip;
    float Num, Accbal, Lpay;
};
int main(int argc, char** argv) {
    int choice, let;
    string sname;
    CusData array[10];
            
     do
     {
        cout<<"Any spaces should be type like this Tom_Middle."<<endl;
        cout<<"Type 1 to enter new data."<<endl;
        cout<<"Type 2 to change data."<<endl;
        cout<<"Type 3 to display all the data."<<endl;
        cout<<"Type 4 to search by name."<<endl;
        cout<<"Type 5 to exit."<<endl;
            cin>>choice;
        switch(choice)
        {
            case 1:
                cout<<"Enter name: ";
                    cin>>array[0].Name;
                cout<<"Enter address: ";
                    cin>>array[0].Address;
                cout<<"Enter city: ";
                    cin>>array[0].City;
                cout<<"Enter state: ";
                    cin>>array[0].State;
                cout<<"Enter zip: ";
                    cin>>array[0].Zip;
                cout<<"Enter telephone number: ";
                    cin>>array[0].Num;
                cout<<"Enter account balance: ";
                    cin>>array[0].Accbal;
                    while(array[0].Accbal<0)
                    {
                        cout<<"No negative numbers please re-enter: ";
                            cin>>array[0].Accbal;
                    }    
                cout<<"Enter date of last payment: ";
                    cin>>array[0].Lpay;
                    break;
            case 2:
                cout<<"Enter number of element to change: ";
                        cin>>let;
                cout<<"Enter name: ";
                    cin>>array[let].Name;
                cout<<"Enter address: ";
                    cin>>array[let].Address;
                cout<<"Enter city: ";
                    cin>>array[let].City;
                cout<<"Enter state: ";
                    cin>>array[let].State;
                cout<<"Enter zip: ";
                    cin>>array[let].Zip;
                cout<<"Enter telephone number: ";
                    cin>>array[let].Num;
                cout<<"Enter account balance: ";
                    cin>>array[let].Accbal;
                while(array[let].Accbal<0)
                {
                     cout<<"No negative numbers please re-enter: ";
                            cin>>array[let].Accbal;
                }    
                cout<<"Enter date of last payment: ";
                    cin>>array[let].Lpay;
                    break;
            case 3:
                for(int i=0;i<10;i++)
                {
                    cout<<"===================="<<endl;
                    cout<<array[i].Name<<endl;
                    cout<<array[i].Address<<endl;
                    cout<<array[i].City<<endl;
                    cout<<array[i].State<<endl;
                    cout<<array[i].Zip<<endl;
                    cout<<setprecision(10)<<array[i].Num<<endl;
                    cout<<array[i].Accbal<<endl;
                    cout<<array[i].Lpay<<endl;
                    cout<<"===================="<<endl;
                } 
                break;
            case 4:
                cout<<"Enter name: ";
                    cin>>sname;
                for(int i=0;i<10;i++)
                {
                    if(array[i].Name.compare(sname)==0)
                    {
                    cout<<"===================="<<endl;
                    cout<<array[i].Name<<endl;
                    cout<<array[i].Address<<endl;
                    cout<<array[i].City<<endl;
                    cout<<array[i].State<<endl;
                    cout<<array[i].Zip<<endl;
                    cout<<setprecision(10)<<array[i].Num<<endl;
                    cout<<array[i].Accbal<<endl;
                    cout<<array[i].Lpay<<endl;
                    cout<<"===================="<<endl;
                    }
                    else
                    {
                        cout<<"No matches found."<<endl;
                    }
                }
                    break;
                        
        }
     }
    while(choice!=5);

    return 0;
}

