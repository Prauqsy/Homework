/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Juan Tellez
 *
 * Created on October 6, 2017, 7:35 PM
 */

#include <iostream>


using namespace std;

struct Weather{
    float tRain, High, Low, Avg;
};
int main() {
    float total,top,bot,sum;
    int Mtop,Mbot;
    Weather array[36];
    string month[12]={"January","February","March", "April", "May", "June", "July", 
                "August", "September", "October", "November", "December"};
    for(int i=0; i<12;i++)
    {
        cout<<"=============================="<<endl;
        cout<<month[i]<<endl;
        cout<<"=============================="<<endl;
        cout<<"Enter total rainfall: ";
            cin>>array[i].tRain;
        cout<<"Enter highest temperature: ";
            cin>>array[i].High;
            while(array[i].High<-100||array[i].High>140)
            {
                cout<<"Please re-enter temperature: ";
                    cin>>array[i].High;
            }
        cout<<"Enter Lowest temperature: ";
            cin>>array[i].Low;
            while(array[i].Low<-100||array[i].Low>140)
            {
                cout<<"Please re-enter temperature";
                    cin>>array[i].Low;
            }        
    }
    
    for(int x=0;x<12;x++)
    {
        total+=array[x].tRain;
        total/12=Rtotal
        array[x].Avg=(array[x].High+array[x].Low)/2;
    }
    for(int y=1;y<12;y++)
    {
        if(array[y].High>top)
        {
            top=array[y].High;
            Mtop=y;
        }
    }    
    for(int a=1;a<12;a++)
    {
        if(array[a].Low<bot)
        {
            bot=array[a].Low;
            Mbot=a;
        }
    }
    for(int z=0;z<12;z++)
    {
        sum+=array[z].Avg;
        sum/12=Rsum
    }
    cout<<"====================================================================="<<endl;
    cout<<"Average monthly rainfall: "<<Rtotal<<endl;
    cout<<"Total rainfall for the year: "<<total<<endl;
    cout<<"Highest temperature for the year: "<<top<<" happened in: "<<month[Mtop]<<endl;
    cout<<"Lowest temperature for the year: "<<bot<<" happened in: "<<month[Mbot]<<endl;
    cout<<"Average of all the monthly average temperatures: "<<Rsum<<endl;
    
    return 0;
}

