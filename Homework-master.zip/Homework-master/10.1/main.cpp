/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Juan Tellez
 *
 * Created on October 12, 2017, 11:28 AM
 */

#include <iostream>
#include <cctype>

using namespace std;

int Word_count(string*);

int main() {
    string String1[50];
    cout<<"Enter String: ";
    cin.getline(String1, 50);
    cout<<"Number of words."<<Word_count(String1)<<endl;
}

int Word_count(string*str, string ch)
{
    int count=1;
    while(str!='\0')
    {
        if(*str==ch)
        count++;
        str++;
    }
    return count;
}


