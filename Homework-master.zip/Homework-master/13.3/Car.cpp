#include "Car.h"
using namespace std;
Car::Car(int yr, string m)
{
    yr=yearModel;
    make=m;
    speed=0;
}
int Car::getYear()
{
    return year;
}
string Car::getMake()
{
    return make;
}
int Car::getSpeed()
{
    return speed;
}
void Car::aclel()
{
    speed=speed+5
}
void Car::break;()
{
    if(speed<25)
        speed=speed-5;
    else
        speed=0;            
}