#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

//Currentcy Constants
const float YEN_P_DOLR=110.89, EUR_P_DOLR=.84;

int main(int argc, char** argv) {
    //Declare Variables 
    float J, D, E;
    
    cout <<"Enter the amount you would like the know the exchange rate for:"<< endl;
    cout <<"$"; 
        //User input
        cin >> D;
        
        //Dollar to Yen and Euro equations
        J=D*YEN_P_DOLR;
        E=D*EUR_P_DOLR;
        
     //Equation output with decimal point constraints            
    cout << fixed << showpoint<< setprecision (2)<< "¥" << J << endl;
    cout << fixed << showpoint << setprecision (2)<<"€" << E << endl;

    return 0;
}

